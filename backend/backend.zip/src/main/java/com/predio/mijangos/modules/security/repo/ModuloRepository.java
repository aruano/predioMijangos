package com.predio.mijangos.modules.security.repo;

import com.predio.mijangos.modules.security.domain.Modulo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModuloRepository extends JpaRepository<Modulo, Integer> { }
