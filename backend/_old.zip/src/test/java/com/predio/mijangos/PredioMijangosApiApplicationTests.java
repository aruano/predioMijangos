package com.predio.mijangos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PredioMijangosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
