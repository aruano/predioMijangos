package com.predio.mijangos.modules.compras.service;

import com.predio.mijangos.modules.compras.domain.Proveedor;
import com.predio.mijangos.modules.compras.dto.*;
import com.predio.mijangos.modules.compras.repo.ProveedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.NoSuchElementException;

@Service
@RequiredArgsConstructor
public class ProveedorServiceImpl implements ProveedorService {

  private final ProveedorRepository repo;

  private ProveedorDTO toDTO(Proveedor e) {
    return ProveedorDTO.builder()
        .id(e.getId())
        .nombre(e.getNombre())
        .direccion(e.getDireccion())
        .telefono(e.getTelefono())
        .celular(e.getCelular())
        .correo(e.getCorreo())
        .observaciones(e.getObservaciones())
        .build();
  }

  private void apply(Proveedor e, ProveedorCreateUpdateDTO d) {
    e.setNombre(d.getNombre());
    e.setDireccion(d.getDireccion());
    e.setTelefono(d.getTelefono());
    e.setCelular(d.getCelular());
    e.setCorreo(d.getCorreo());
    e.setObservaciones(d.getObservaciones());
  }

  @Override
  public Page<ProveedorDTO> list(String q, Pageable pageable) {
    return repo.search(q, pageable).map(this::toDTO);
  }

  @Override
  public ProveedorDTO getById(Integer id) {
    var e = repo.findById(id).orElseThrow(() -> new NoSuchElementException("Proveedor no encontrado"));
    return toDTO(e);
  }

  @Override
  public ProveedorDTO create(ProveedorCreateUpdateDTO dto) {
    if (dto.getNombre() != null && repo.existsByNombreIgnoreCase(dto.getNombre())) {
      throw new IllegalArgumentException("Ya existe un proveedor con ese nombre");
    }
    var e = new Proveedor();
    apply(e, dto);
    return toDTO(repo.save(e));
  }

  @Override
  public ProveedorDTO update(Integer id, ProveedorCreateUpdateDTO dto) {
    var e = repo.findById(id).orElseThrow(() -> new NoSuchElementException("Proveedor no encontrado"));
    // validación nombre único (si cambió)
    if (dto.getNombre() != null && !dto.getNombre().equalsIgnoreCase(e.getNombre())
        && repo.existsByNombreIgnoreCase(dto.getNombre())) {
      throw new IllegalArgumentException("Ya existe un proveedor con ese nombre");
    }
    apply(e, dto);
    return toDTO(repo.save(e));
  }

    @Override
  public ProveedorDTO activar(Integer id) {
    var e = repo.findById(id)
        .orElseThrow(() -> new NoSuchElementException("Proveedor no encontrado"));
    e.setActivo(true);
    return toDTO(repo.save(e));
  }

  @Override
  public ProveedorDTO desactivar(Integer id) {
    var e = repo.findById(id)
        .orElseThrow(() -> new NoSuchElementException("Proveedor no encontrado"));
    e.setActivo(false);
    return toDTO(repo.save(e));
  }
}
