package com.predio.mijangos.modules.geo.repo;

import com.predio.mijangos.modules.geo.domain.Departamento;
import org.springframework.data.jpa.repository.JpaRepository;

/** SRP: acceso a datos de Departamento. */
public interface DepartamentoRepository extends JpaRepository<Departamento, Integer> { }
