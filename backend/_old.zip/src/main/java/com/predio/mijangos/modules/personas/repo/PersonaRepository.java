package com.predio.mijangos.modules.personas.repo;

import com.predio.mijangos.modules.personas.domain.Persona;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonaRepository extends JpaRepository<Persona, Integer> { }
