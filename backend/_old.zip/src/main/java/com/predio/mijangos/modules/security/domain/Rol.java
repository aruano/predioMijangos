package com.predio.mijangos.modules.security.domain;

import jakarta.persistence.*;
import lombok.*;

/** Entidad Rol del dominio. */
@Entity
@Table(name = "TBL_Rol")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Rol {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "nombre", nullable = false, unique = true, length = 50)
  private String nombre;

  @Column(name = "descripcion", length=200)
  private String descripcion;

  @Column(name = "admin", nullable = false)
  private boolean admin;
}
