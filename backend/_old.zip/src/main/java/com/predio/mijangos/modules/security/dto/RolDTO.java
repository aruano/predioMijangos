package com.predio.mijangos.modules.security.dto;

/** Rol expuesto al cliente. */
public record RolDTO(Integer id, String nombre, boolean admin) {}
