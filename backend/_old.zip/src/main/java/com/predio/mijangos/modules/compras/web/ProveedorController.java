package com.predio.mijangos.modules.compras.web;

import com.predio.mijangos.core.response.ApiResponse;
import com.predio.mijangos.modules.compras.dto.*;
import com.predio.mijangos.modules.compras.service.ProveedorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/providers")
@RequiredArgsConstructor
@Tag(name = "Proveedores", description = "CRUD de Proveedores (Compras)")
public class ProveedorController {

  private final ProveedorService service;

  @Operation(summary = "Lista proveedores (paginado / búsqueda q)")
  @GetMapping
  @PreAuthorize("hasAnyRole('ADMIN','OFICINA')")
  public ResponseEntity<ApiResponse<Page<ProveedorDTO>>> list(
      @RequestParam(required = false) String q,
      @RequestParam(defaultValue = "0") int page,
      @RequestParam(defaultValue = "10") int size
  ) {
    var pageable = PageRequest.of(page, size, Sort.by("nombre").ascending());
    var body = service.list(q, pageable);
    return ResponseEntity.ok(ApiResponse.ok("OK", body));
  }

  @Operation(summary = "Obtiene proveedor por id")
  @GetMapping("/{id}")
  @PreAuthorize("hasAnyRole('ADMIN','OFICINA')")
  public ResponseEntity<ApiResponse<ProveedorDTO>> get(@PathVariable Integer id) {
    return ResponseEntity.ok(ApiResponse.ok("OK", service.getById(id)));
  }

  @Operation(summary = "Crea proveedor")
  @PostMapping
  @PreAuthorize("hasAnyRole('ADMIN','OFICINA')")
  public ResponseEntity<ApiResponse<ProveedorDTO>> create(@Valid @RequestBody ProveedorCreateUpdateDTO dto) {
    return ResponseEntity.ok(ApiResponse.ok("Creado", service.create(dto)));
  }

  @Operation(summary = "Actualiza proveedor")
  @PutMapping("/{id}")
  @PreAuthorize("hasAnyRole('ADMIN','OFICINA')")
  public ResponseEntity<ApiResponse<ProveedorDTO>> update(
      @PathVariable Integer id, @Valid @RequestBody ProveedorCreateUpdateDTO dto) {
    return ResponseEntity.ok(ApiResponse.ok("Actualizado", service.update(id, dto)));
  }

  @Operation(summary = "Activa un proveedor")
  @PatchMapping("/{id}/activar")
  @PreAuthorize("hasAnyRole('ADMIN','OFICINA')")
  public ResponseEntity<ApiResponse<Object>> activar(@PathVariable Integer id) {
    service.activar(id);
    return ResponseEntity.ok(ApiResponse.ok("Proveedor activado", null));
  }

  @Operation(summary = "Desactiva un proveedor")
  @PatchMapping("/{id}/desactivar")
  @PreAuthorize("hasAnyRole('ADMIN','OFICINA')")
  public ResponseEntity<ApiResponse<Object>> desactivar(@PathVariable Integer id) {
    service.desactivar(id);
    return ResponseEntity.ok(ApiResponse.ok("Proveedor desactivado", null));
  }
}
