package com.predio.mijangos.modules.geo.web;

import com.predio.mijangos.core.response.ApiResponse;
import com.predio.mijangos.modules.geo.dto.*;
import com.predio.mijangos.modules.geo.service.GeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/** Endpoints de catálogos geográficos (documentados). */
@RestController
@RequestMapping("/api/geo")
@RequiredArgsConstructor
@Tag(name="Geo", description="Catálogos de Departamento y Municipio")
public class GeoController {
  private final GeoService geoService;

  @Operation(summary="Lista los departamentos")
  @GetMapping("/departamentos")
  public ResponseEntity<ApiResponse<List<DepartamentoDTO>>> departamentos() {
    return ResponseEntity.ok(ApiResponse.ok("OK", geoService.listarDepartamentos()));
  }

  @Operation(summary="Lista municipios por departamento")
  @GetMapping("/municipios")
  public ResponseEntity<ApiResponse<List<MunicipioDTO>>> municipios(@RequestParam Integer departamentoId) {
    return ResponseEntity.ok(ApiResponse.ok("OK", geoService.listarMunicipiosPorDepartamento(departamentoId)));
  }
}
