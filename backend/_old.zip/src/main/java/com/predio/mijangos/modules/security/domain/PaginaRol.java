package com.predio.mijangos.modules.security.domain;

import jakarta.persistence.*;
import lombok.*;

/** Relación Página-Rol (permiso de acceso). */
@Entity @Table(name = "TBL_Pagina_Rol")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PaginaRol {
  @EmbeddedId
  private PaginaRolId id;

  @ManyToOne(fetch = FetchType.LAZY) @MapsId("paginaId")
  @JoinColumn(name = "id_pagina")
  private Pagina pagina;

  @ManyToOne(fetch = FetchType.LAZY) @MapsId("rolId")
  @JoinColumn(name = "id_rol")
  private Rol rol;
}
