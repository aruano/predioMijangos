package com.predio.mijangos.modules.geo.dto;

/** DTO de lectura de Departamento (ISP). */
public record DepartamentoDTO(Integer id, String nombre) {}
