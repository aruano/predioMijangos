package com.predio.mijangos.modules.geo.service;

import com.predio.mijangos.modules.geo.dto.*;
import java.util.List;

/** DIP: contrato del servicio de geocatálogos. */
public interface GeoService {
  List<DepartamentoDTO> listarDepartamentos();
  List<MunicipioDTO> listarMunicipiosPorDepartamento(Integer departamentoId);
}
