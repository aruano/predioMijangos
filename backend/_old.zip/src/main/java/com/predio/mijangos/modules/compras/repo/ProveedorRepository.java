package com.predio.mijangos.modules.compras.repo;

import com.predio.mijangos.modules.compras.domain.Proveedor;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface ProveedorRepository extends JpaRepository<Proveedor, Integer> {

  @Query("""
      SELECT p FROM Proveedor p
      WHERE (:q IS NULL OR :q = '' OR
            LOWER(p.nombre) LIKE LOWER(CONCAT('%', :q, '%')) OR
            LOWER(p.correo) LIKE LOWER(CONCAT('%', :q, '%')) OR
            LOWER(p.telefono) LIKE LOWER(CONCAT('%', :q, '%')) OR
            LOWER(p.celular) LIKE LOWER(CONCAT('%', :q, '%')))
      """)
  Page<Proveedor> search(@Param("q") String q, Pageable pageable);

  boolean existsByNombreIgnoreCase(String nombre);
 
}
