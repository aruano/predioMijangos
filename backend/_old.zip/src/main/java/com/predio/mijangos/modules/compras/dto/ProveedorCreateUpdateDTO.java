package com.predio.mijangos.modules.compras.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ProveedorCreateUpdateDTO {

  @NotBlank(message = "El nombre es obligatorio")
  @Size(max = 100, message = "Nombre máximo 100 caracteres")
  private String nombre;

  @Size(max = 150, message = "Dirección máximo 150 caracteres")
  private String direccion;

  @Size(max = 15, message = "Teléfono máximo 15 caracteres")
  private String telefono;

  @Size(max = 15, message = "Celular máximo 15 caracteres")
  private String celular;

  @Email(message = "Correo inválido")
  @Size(max = 100, message = "Correo máximo 100 caracteres")
  private String correo;

  @Size(max = 300, message = "Observaciones máximo 300 caracteres")
  private String observaciones;
}
