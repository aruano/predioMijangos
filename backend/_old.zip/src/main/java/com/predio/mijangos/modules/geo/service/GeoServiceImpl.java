package com.predio.mijangos.modules.geo.service;

import com.predio.mijangos.modules.geo.repo.*;
import com.predio.mijangos.modules.geo.dto.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** Implementación del servicio de geocatálogos (SRP). */
@Service @RequiredArgsConstructor
public class GeoServiceImpl implements GeoService {
  private final DepartamentoRepository departamentoRepo;
  private final MunicipioRepository municipioRepo;

  @Override
  public java.util.List<DepartamentoDTO> listarDepartamentos() {
    return departamentoRepo.findAll().stream()
      .map(d -> new DepartamentoDTO(d.getId(), d.getNombre()))
      .toList();
  }
  @Override
  public java.util.List<MunicipioDTO> listarMunicipiosPorDepartamento(Integer deptoId) {
    return municipioRepo.findByDepartamento_Id(deptoId).stream()
      .map(m -> new MunicipioDTO(m.getId(), m.getNombre(),
          m.getDepartamento() != null ? m.getDepartamento().getId() : null))
      .toList();
  }
}
