package com.predio.mijangos.modules.security.domain;

import jakarta.persistence.*;
import lombok.*;
import java.io.Serializable;

/** Clave compuesta de TBL_Pagina_Rol. */
@Embeddable
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @EqualsAndHashCode
public class PaginaRolId implements Serializable {
  @Column(name = "id_pagina") private Integer paginaId;
  @Column(name = "id_rol")    private Integer rolId;
}
