package com.predio.mijangos.modules.security.domain;

import com.predio.mijangos.modules.personas.domain.Persona;
import jakarta.persistence.*;
import lombok.*;
import java.util.Set;

@Entity @Table(name = "TBL_Usuario")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Usuario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length=50, unique = true, nullable = false)
    private String usuario;

    @Column(length=200, nullable = false)
    private String password; // BCrypt

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_persona")
    private Persona persona;

    private Boolean activo;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "TBL_Usuario_Rol",
        joinColumns = @JoinColumn(name = "id_usuario"),
        inverseJoinColumns = @JoinColumn(name = "id_rol")
    )
    private Set<Rol> roles;
}
