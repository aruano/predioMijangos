package com.predio.mijangos.modules.geo.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

/** Catálogo de Departamentos (Guatemala). */
@Entity @Table(name="TBL_Departamento")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Departamento {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @NotBlank
  @Column(name="nombre", length=100, nullable=false, unique=true)
  private String nombre;
}
