package com.predio.mijangos.modules.compras.service;

import com.predio.mijangos.modules.compras.dto.*;
import org.springframework.data.domain.*;

public interface ProveedorService {
  Page<ProveedorDTO> list(String q, Pageable pageable);
  ProveedorDTO getById(Integer id);
  ProveedorDTO create(ProveedorCreateUpdateDTO dto);
  ProveedorDTO update(Integer id, ProveedorCreateUpdateDTO dto);
  ProveedorDTO activar(Integer id);
  ProveedorDTO desactivar(Integer id);
}
