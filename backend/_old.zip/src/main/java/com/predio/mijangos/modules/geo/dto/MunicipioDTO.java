// modules/geo/dto/MunicipioDTO.java
package com.predio.mijangos.modules.geo.dto;

/** DTO de lectura de Municipio (ISP). */
public record MunicipioDTO(Integer id, String nombre, Integer departamentoId) {}
