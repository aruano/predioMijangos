package com.predio.mijangos.modules.security.domain;

import jakarta.persistence.*;
import lombok.*;

/** Entidad de módulo principal (Seguridad, Inventario, Ventas, etc.). */
@Entity @Table(name = "TBL_Modulo")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Modulo {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(length = 100, nullable = false, unique = true)
  private String nombre;
}
