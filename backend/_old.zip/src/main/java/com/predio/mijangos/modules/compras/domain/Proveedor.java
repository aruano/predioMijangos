package com.predio.mijangos.modules.compras.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TBL_Proveedor",
        indexes = {
            @Index(name = "idx_proveedor_nombre", columnList = "nombre"),
            @Index(name = "idx_proveedor_correo", columnList = "correo")
        })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 100, unique = true, nullable = false)
    private String nombre;

    @Column(length = 150)
    private String direccion;

    @Column(length = 15)
    private String telefono;

    @Column(length = 15)
    private String celular;

    @Column(length = 100)
    private String correo;

    @Column(length = 300)
    private String observaciones;

    private Boolean activo;
}
