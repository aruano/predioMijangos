package com.predio.mijangos.modules.security.domain;

import jakarta.persistence.*;
import lombok.*;

/** Submódulo/página dentro de un módulo (Usuarios, Roles, Productos, etc.). */
@Entity @Table(name = "TBL_Pagina")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Pagina {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "id_modulo", nullable = false)
  private Modulo modulo;

  @Column(length = 100, nullable = false, unique = true)
  private String nombre;

  private Boolean movil;          // true si es para app móvil
  @Column(name = "icon", length = 100)   private String icon;
  @Column(name = "redirect", length = 100)   private String redirect;
}
