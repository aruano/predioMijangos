package com.predio.mijangos.modules.geo.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

/** Catálogo de Municipios (pertenece a un Departamento). */
@Entity @Table(name="TBL_Municipio")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Municipio {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @NotBlank
  @Column(name="nombre", length=100, nullable=false)
  private String nombre;

  @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="id_departamento")
  private Departamento departamento;
}
