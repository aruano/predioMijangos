-- Crear tabla Proveedores
CREATE TABLE IF NOT EXISTS TBL_Proveedor (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) UNIQUE,
  direccion VARCHAR(150),
  telefono VARCHAR(15),
  celular VARCHAR(15),
  correo VARCHAR(100),
  observaciones VARCHAR(300),
  activo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_proveedor_nombre ON TBL_Proveedor (nombre);
CREATE INDEX idx_proveedor_correo ON TBL_Proveedor (correo);